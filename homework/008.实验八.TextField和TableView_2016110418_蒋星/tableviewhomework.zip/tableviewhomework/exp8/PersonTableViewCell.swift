//
//  PersonTableViewCell.swift
//  exp8
//
//  Created by 505007 on 2018/11/26.
//  Copyright © 2018年 505007. All rights reserved.
//

import UIKit

class PersonTableViewCell: UITableViewCell {

    @IBOutlet weak var lblidentifiy: UILabel!
    
    @IBOutlet weak var userimage: UIImageView!
    
    @IBOutlet weak var switchsex: UISwitch!
    
    @IBOutlet weak var lbldesc: UILabel!
    
    @IBOutlet weak var lblage: UILabel!
    
    @IBOutlet weak var lblname: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
