//
//  Person.swift
//  exp8
//
//  Created by 505007 on 2018/11/26.
//  Copyright © 2018年 505007. All rights reserved.
//

import Foundation

enum Gender:Int{
    case male = 1
    case female = 4
}

class Person:CustomStringConvertible {
    var firstName:String
    var lastName:String
    var age:Int
    var gender:Gender
    
    init(firstName:String,lastName:String,age:Int,gender:Gender) {
        self.age = age
        self.lastName = lastName
        self.firstName = firstName
        self.gender = gender
    }
    
    var fullName:String{
        get{
            return firstName + " " + lastName
        }
    }
    
    func run(){
        print("Person \(fullName) is running")
    }
    
    convenience init(firstName:String){
        self.init(firstName: firstName,lastName:"king",age:18,gender: Gender.male)
    }
    
    static func == (one:Person,two:Person)-> Bool{
        if(one.age == two.age) && (one.firstName == two.firstName) && (one.lastName == two.lastName)
            && (one.gender == two.gender){
            return true;
        }else{
            return false;
        }
    }
    
    static func != (one:Person,two:Person)-> Bool{
        if(one.age == two.age) && (one.firstName == two.firstName) && (one.lastName == two.lastName)
            && (one.gender == two.gender){
            return false;
        }else{
            return true;
        }
    }
    
    var description:String {
        return " name: \(firstName) \(lastName) age:\(age) sex:\(gender)  "
    }
}

class Teacher:Person{
    var title:String
    
    init(firstName: String, lastName: String, age: Int, gender: Gender,title:String) {
        self.title = title
        super.init(firstName: firstName, lastName: lastName, age: age, gender: gender)
    }
    
    override var description:String{
        return " name: \(firstName) \(lastName) age:\(age) sex:\(gender)  title:\(title) "
    }
    
    override func run() {
        print("Teacher \(fullName) is running")
    }
    
}

class Student:Person{
    var stuNo:String
    
    init(firstName: String, lastName: String, age: Int, gender: Gender,stuNo:String) {
        self.stuNo = stuNo
        super.init(firstName: firstName, lastName: lastName, age: age, gender: gender)
    }
    
    
    override var description:String{
        return " name: \(firstName) \(lastName) age:\(age) sex:\(gender)  stuNo:\(stuNo) "
    }
    override func run() {
        print("Student \(fullName) is running")
    }
    
}
