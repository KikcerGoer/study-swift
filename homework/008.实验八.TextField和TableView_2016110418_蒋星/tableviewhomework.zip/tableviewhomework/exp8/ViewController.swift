//
//  ViewController.swift
//  exp8
//
//  Created by 505007 on 2018/11/26.
//  Copyright © 2018年 505007. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var txtfisrtname: UITextField!
    
    @IBOutlet weak var txtlastname: UITextField!
    
    @IBOutlet weak var switchsex: UISwitch!
    
    @IBOutlet weak var txtage: UITextField!
    
    @IBOutlet weak var txtid: UITextField!
    
    @IBAction func add(_ sender: UIButton) {
        if let firstname:String = txtfisrtname.text{
            if let lastname:String = txtlastname.text{
                if let age:String = txtage.text{
                   if let id:String = txtid.text {
                         /*
                            print(firstname)
                            print(lastname)
                            print(age)
                            print(id)
                         */
                    
                        if btnsave.titleLabel?.text == "添加" {
                        
                           let sex:Gender =  switchsex.isOn == true ? Gender.male : Gender.female
                           let p =  Student(firstName:firstname,lastName:lastname,age:Int(age)!,gender:sex,stuNo:id)
                        
                           plist.append(p)
                        }else{
                            if let shoose =  plist.filter({ $0 is Student }).filter({ ($0 as? Student)?.stuNo == txtid.text }).first{
                                shoose.firstName = firstname
                                shoose.lastName = lastname
                                shoose.age = Int(age)!
                                shoose.gender = switchsex.isOn == true ? Gender.male : Gender.female
                            }
                            btnsave.titleLabel?.text = "添加"
                            txtid.isEnabled = true
                        }
                        tableview.reloadData()
                        txtfisrtname.text = ""
                        txtlastname.text = ""
                        txtage.text = ""
                        txtid.text = ""
                        switchsex.isOn = true
                    
                   }
                }
            }
        }
    }
    var plist:[Person] = [Person]()
    
    @IBOutlet weak var btnsave: UIButton!
    
    @IBAction func editclick(_ sender: UIButton) {
        if let row = tableview.indexPathForSelectedRow?.row{
            let shoose = plist[row]
            
            if shoose is Student{
                txtfisrtname.text = shoose.firstName
                txtlastname.text = shoose.lastName
                txtage.text = shoose.age.description
                switch shoose.gender{
                case .male:
                    switchsex.isOn = true
                default:
                    switchsex.isOn = false
                }
                
                txtid.text = (shoose as? Student)?.stuNo
                
                txtid.isEnabled = false
                
                btnsave.titleLabel?.text = "保存"
            }
        }
    }
    
    @IBAction func deleteclick(_ sender: UIButton) {
        tableview.isEditing = !tableview.isEditing
    }
    
    @IBAction func newpage(_ sender: UIButton) {
        tableview.reloadData()
        txtfisrtname.text = ""
        txtlastname.text = ""
        txtage.text = ""
        txtid.text = ""
        switchsex.isOn = true
        txtid.isEnabled = true
    }
    
    @IBAction func clear(_ sender: UIButton) {
        txtfisrtname.text = ""
        txtlastname.text = ""
        txtage.text = ""
        txtid.text = ""
        switchsex.isOn = true
        txtid.isEnabled = true
    }
 
    @IBOutlet weak var tableview: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return plist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "person", for: indexPath) as? PersonTableViewCell
        let person = plist[indexPath.row]
        if person is Student{
            cell?.lblname.text = person.fullName;
            
            switch person.gender{
            case .female:
                cell?.switchsex.isOn = false
            default:
                cell?.switchsex.isOn = true
                
            }
            cell?.lblidentifiy.text = "祖国的花朵"
            cell?.lblage.text = "年龄:\(person.age)";
            cell?.lbldesc.text = (person as! Student).description
            cell?.userimage.image = UIImage(named:"dog")
            
            cell?.userimage.layer.masksToBounds = true
            
            cell?.userimage.layer.cornerRadius = (cell?.userimage.frame.size.width)!/2
        }else {
            cell?.lblname.text = person.fullName;
            
            switch person.gender{
            case .female:
                cell?.switchsex.isOn = false
            default:
                cell?.switchsex.isOn = true
                
            }
            cell?.lblidentifiy.text = "尊敬的人民教师"
            cell?.lblage.text = "年龄:\(person.age)";
            cell?.lbldesc.text = (person as! Teacher).description
            cell?.userimage.image = UIImage(named:"cat")
            cell?.userimage.layer.masksToBounds = true
            
            cell?.userimage.layer.cornerRadius = (cell?.userimage.frame.size.width)!/2
        }
        
        return cell!;
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            plist.remove(at: indexPath.row)
            //tableview.reloadData()
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            return "人员列表"
    }
    
    //状态列是否隐藏
    override var prefersStatusBarHidden: Bool{
        return false;
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let p =  Student(firstName:"kicker0",lastName:"king",age:21,gender:Gender.male,stuNo:"banzhureaan0")
        let p0 = Student(firstName:"kicker10",lastName:"king",age:21,gender:Gender.female,stuNo:"banzhurensd0")
        let p1 = Teacher(firstName:"kicker1",lastName:"king",age:21,gender:Gender.male,title:"banzhuren0")
        let p3 = Teacher(firstName:"kicker2",lastName:"king",age:21,gender:Gender.male,title:"banzhuren1")
        let p4 = Teacher(firstName:"kicker3",lastName:"king",age:21,gender:Gender.female,title:"banzhuren2")
        let p5 = Teacher(firstName:"kicker4",lastName:"king",age:21,gender:Gender.male,title:"banzhuren3")
        let p2 = Student(firstName:"kicker5",lastName:"king",age:21,gender:Gender.female,stuNo:"2016110418")
        
        plist.append(p)
        plist.append(p0)
        plist.append(p1)
        plist.append(p2)
        plist.append(p3)
        plist.append(p4)
        plist.append(p5)
        print(plist.count)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /* 实现移动效果呢 */
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let source = plist.remove(at: sourceIndexPath.row)
        plist.insert(source, at: destinationIndexPath.row)
    }
    
    
    
}

