//
//  ViewController.swift
//  exp12
//
//  Created by 505007 on 2018/12/15.
//  Copyright © 2018年 kicker. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfNumber: UITextField!
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func Back(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func add(_ sender: Any) {
        let person = Person(context:context)
        person.name = tfName.text
        person.phone = tfNumber.text
        appDelegate.saveContext()
    }
    

    @IBAction func deletePerson(_ sender: Any) {
        let fetch:NSFetchRequest<Person> = Person.fetchRequest()
        fetch.predicate = NSPredicate(format:"name=%@",tfName.text!)
        let persons = try? context.fetch(fetch)
        if let p = persons?.first{
            context.delete(p)
            appDelegate.saveContext()
        }
    }
    
    
    @IBAction func updatePerson(_ sender: Any) {
        let fetch:NSFetchRequest<Person> = Person.fetchRequest()
        fetch.predicate = NSPredicate(format:"name=%@",tfName.text!)
        let persons = try? context.fetch(fetch)
        if let p = persons?.first{
            p.phone  = tfNumber.text
            appDelegate.saveContext()
        }
    }
    
    @IBAction func quertPerson(_ sender: Any) {
        let fetch:NSFetchRequest<Person> = Person.fetchRequest()
        fetch.predicate = NSPredicate(format:"name=%@",tfName.text!)
        let persons = try? context.fetch(fetch)
        if let p = persons?.first{
            tfNumber.text = p.phone
        }
        
    }
    
}

