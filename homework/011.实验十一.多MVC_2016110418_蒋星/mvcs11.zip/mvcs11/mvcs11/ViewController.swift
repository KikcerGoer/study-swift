//
//  ViewController.swift
//  mvcs11
//
//  Created by student on 2018/12/13.
//  Copyright © 2018年 wb. All rights reserved.
//

import UIKit

protocol StudentProtocal {
    func change(name:String,no:String)
}


class ViewController: UIViewController,StudentProtocal {
    func change(name: String, no: String) {
        self.no = no
        self.name = name
    }
    

    var no:String = ""
    var name:String = ""
    
    @IBOutlet weak var stuNo: UITextField!
    @IBOutlet weak var stuName: UITextField!
    
    @IBAction func zhengxiangchuancan(_ sender: UIButton) {
        let secVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecondView")
            as! SecondViewController;
        secVC.no = stuNo.text!
        secVC.name = stuName.text!
        self.navigationController?.pushViewController(secVC, animated: true)
        //用于反向传参
        secVC.delegate = self
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        stuNo.text = no
        stuName.text = name
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        stuNo.text = no
        stuName.text = name
        // Do any additional setup after loading the view, typically from a nib.
    }
   
    @IBAction func gosecond(_ sender: UIButton) {
        let secVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecondView")
        //present(secVC, animated: true, completion: nil)
        //present must match dismiss
        
        //use nagvigator
        //dismiss not worker
        self.navigationController?.pushViewController(secVC, animated: true)
        
        
    }
    
    @IBAction func gotoThird(_ sender: Any) {
        let secVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ThirdView")
        present(secVC, animated: true, completion: nil)
        
    }

    
}

