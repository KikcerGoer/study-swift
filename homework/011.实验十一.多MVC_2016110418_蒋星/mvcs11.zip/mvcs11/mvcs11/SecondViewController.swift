//
//  SecondViewController.swift
//  mvcs11
//
//  Created by student on 2018/12/13.
//  Copyright © 2018年 wb. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var no:String = ""
    var name:String = ""
    
    @IBAction func sendright(_ sender: Any) {
        //通过代理来实现
        no = stuNo_.text!
        name = stuName_.text!
        
        delegate?.change(name: name, no: no)
        navigationController?.popViewController(animated: true)
    }
    var delegate:StudentProtocal?
    
    @IBOutlet weak var stuNo_: UITextField!
    @IBOutlet weak var stuName_: UITextField!
    
    //暴力反向传值
    @IBAction func sendbaoli(_ sender: Any) {
        //这是错误的
        no = stuNo_.text!
        name = stuName_.text!
        
        for vc in self.navigationController!.viewControllers{
            if let firstVC = vc as? ViewController{
                firstVC.no = no
                firstVC.name = name
            }
        }
        navigationController?.popViewController(animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        stuNo_.text = no
        stuName_.text = name
        // Do any additional setup after loading the view.
    }
    
    @IBAction func GoBackFirst(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        //dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
