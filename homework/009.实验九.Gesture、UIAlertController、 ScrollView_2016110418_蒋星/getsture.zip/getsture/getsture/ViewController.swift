//
//  ViewController.swift
//  getsture
//
//  Created by 505007 on 2018/11/26.
//  Copyright © 2018年 505007. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addLable(_ sender: UIButton) {
        let x_  = Int(arc4random()) % Int(view.bounds.width)
        let y_  = Int(arc4random()) % Int(view.bounds.height)
        
        let lable = UILabel(frame:CGRect(x:x_,y:y_,width:30,height:30));
        
        lable.text = "A"
        
        lable.textAlignment = .center
        lable.backgroundColor = UIColor.red
        
        lable.layer.shadowColor = UIColor.gray.cgColor
        lable.layer.shadowOffset = CGSize(width:5,height:5)
        
        lable.layer.shadowOpacity = 1
    
        //拖拽手势
        let panRecognizer = UIPanGestureRecognizer(target:self,action:#selector(pan(recognizer:)))
        lable.addGestureRecognizer(panRecognizer)
        //让lable 可以响应手势
        lable.isUserInteractionEnabled = true
        
        view.addSubview(lable)
        
    }
    
    @objc func pan(recognizer:UIPanGestureRecognizer){
        
        switch recognizer.state {
        case .changed:
            fallthrough
        case .ended:
            let translation = recognizer.translation(in:self.view)
            recognizer.view?.center.x += translation.x
            recognizer.view?.center.y += translation.y
            //防止一下掉下去
            
            recognizer.setTranslation(.zero, in: self.view)
        default:
            break
        }
    }
    
    
    @IBAction func deleteLabel(_ sender: UIButton) {
        for mview in view.subviews
        {
            if mview is UILabel{
                mview.removeFromSuperview()
            }
        }
    }
    
    @IBAction func moveLabel(_ sender: UIButton) {
        for mview in view.subviews
        {
            if mview is UILabel{
                UIView.animate(withDuration: 1){
                    let x_  = Int(arc4random()) % Int(self.view.bounds.width)
                    let y_  = Int(arc4random()) % Int(self.view.bounds.height)
                    
                    mview.center.x = CGFloat(x_)
                    mview.center.y = CGFloat(y_)
                }
                
            }
        }
    }
}

