//
//  CircleView.swift
//  getsture
//
//  Created by 505007 on 2018/11/26.
//  Copyright © 2018年 505007. All rights reserved.
//

import UIKit

@IBDesignable
//IBDesignable主要用于xcode版本的所见即所得（实时渲染）
class CircleView: UIView {

    @IBInspectable var fillColor:UIColor?
    @IBInspectable var strokeColor:UIColor?
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    */
    
    func setup(){
        //拖拽手势
        let panRecognizer = UIPanGestureRecognizer(target:self,action:#selector(pan(recognizer:)))
        self.addGestureRecognizer(panRecognizer)
        //伸缩手势
        let pinchRecognizer = UIPinchGestureRecognizer(target:self,action:#selector(pinch(recognizer:)))
        self.addGestureRecognizer(pinchRecognizer)
        //点击手势
        let tapRecognizer = UITapGestureRecognizer(target:self,action:#selector(tap(recognizer:)))
        self.addGestureRecognizer(tapRecognizer)
        
        tapRecognizer.numberOfTouchesRequired = 1
        tapRecognizer.numberOfTapsRequired = 2
        
        //选择手势
        let rotationRecognizer = UIRotationGestureRecognizer(target:self,action:#selector(rotation(recognizer:)))
        self.addGestureRecognizer(rotationRecognizer)
        isUserInteractionEnabled = true
        
        
        
    }
    
    @objc func rotation(recognizer:UIRotationGestureRecognizer){
        recognizer.view?.transform = (recognizer.view?.transform.rotated(by: recognizer.rotation))!
        recognizer.rotation = 0
        /*
        switch recognizer.state {
        case .began:
            fallthrough
        case .ended:
            let angle = recognizer.rotation * (180/(CGFloat(M_PI)))
            self.transform.rotated(by: angle)
        default:
            break
        }
       */
    }
    
    //拖拽处理函数
    @objc func pan(recognizer:UIPanGestureRecognizer){
        
        switch recognizer.state {
        case .changed:
            fallthrough
        case .ended:
            let translation = recognizer.translation(in:self)
            center.x += translation.x
            center.y += translation.y
            //防止一下掉下去
            
            recognizer.setTranslation(.zero, in: self)
        default:
            break
        }
    }
    
    //伸缩处理函数
    @objc func pinch(recognizer:UIPinchGestureRecognizer){
        
        switch recognizer.state {
        case .changed:
            fallthrough
        case .ended:
            bounds.size = CGSize(width:bounds.width * recognizer.scale,height:bounds.height * recognizer.scale)
            //让它在还原本来多大小
            recognizer.scale = 1
        default:
            break
        }
    }
    
    //点击处理函数
    @objc func tap(recognizer:UITapGestureRecognizer){
        
        switch recognizer.state {
        case .recognized:
            print("double clicked")
        default:
            break
        }
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
    
    override func draw(_ rect: CGRect) {
        let path = UIBezierPath(ovalIn:rect)
        fillColor?.setFill()
        strokeColor?.setStroke()
        path.fill()
        path.stroke()
    }
    

}
