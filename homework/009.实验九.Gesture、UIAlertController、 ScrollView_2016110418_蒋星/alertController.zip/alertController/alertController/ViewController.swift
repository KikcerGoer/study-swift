//
//  ViewController.swift
//  alertController
//
//  Created by 505007 on 2018/11/27.
//  Copyright © 2018年 505007. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func alertsheet(_ sender: UIButton) {
        //弹出选项表单
        let alert = UIAlertController(title:"action sheet",message:"请选择一种颜色",preferredStyle:.actionSheet);
        alert.addAction(UIAlertAction(title:"热情如火",style:.default,handler:{ (action) in self.view.backgroundColor = UIColor.red }))
        alert.addAction(UIAlertAction(title:"青青草原",style:.default,handler:{ (action) in self.view.backgroundColor = UIColor.green }))
        alert.addAction(UIAlertAction(title:"湛蓝胜海",style:.destructive,handler:{ (action) in self.view.backgroundColor = UIColor.blue }))
        alert.addAction(UIAlertAction(title:"北国无疆",style:.cancel,handler:{ (action) in self.view.backgroundColor = UIColor.white }))
        
        //弹出警告框
        present(alert,animated: true,completion: nil)
        
    }
    
    @IBAction func alert(_ sender: UIButton) {
        //弹出简单警告
        let alert = UIAlertController(title:"警告",message:"你的登陆身份不明确",preferredStyle:.alert);
        alert.addAction(UIAlertAction(title:"登陆",style:.default,handler:{ (action) in
            
            if let userid = alert.textFields?.first?.text {
                if(userid != ""){
                    if let userpwd = alert.textFields?.last?.text{
                        if( userpwd != ""){
                            print(userid)
                            print(userpwd)
                        }
                    }
                }
            }
            
            
            
        }))
        alert.addAction(UIAlertAction(title:"取消",style:.cancel,handler:{ (action) in  }))
        
        //弹出输入框
        
        alert.addTextField(configurationHandler: {(textField) in
            textField.placeholder = "请输入账号"
        });
        
        alert.addTextField(configurationHandler: {(textField) in
            textField.placeholder = "请输入密码"
            //设置为密文
            textField.isSecureTextEntry = true
        });
        
        //弹出警告
        present(alert,animated: true,completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

