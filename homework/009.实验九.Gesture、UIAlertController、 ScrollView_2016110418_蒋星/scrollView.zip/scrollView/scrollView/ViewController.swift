//
//  ViewController.swift
//  scrollView
//
//  Created by 505007 on 2018/11/27.
//  Copyright © 2018年 505007. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIScrollViewDelegate {

    @IBOutlet weak var scrollview: UIScrollView!
    
    @IBOutlet weak var pageControl: UIPageControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        for i in 1...7 {
            let imageView = UIImageView(image:UIImage(named:"\(i)"))
            //适应屏幕
            imageView.contentMode = .scaleAspectFit
            imageView.frame = CGRect(x: CGFloat(i - 1 ) * scrollview.bounds.width,y:0,width:scrollview.bounds.width, height:scrollview.bounds.height)
            scrollview.addSubview(imageView)
        }
        scrollview.contentSize = CGSize(width: 7 * scrollview.bounds.width,height:scrollview.bounds.height)
        
        //支持分页
        scrollview.isPagingEnabled = true
        //取消下面的默认水平滑动条显示
        scrollview.showsHorizontalScrollIndicator = false
        pageControl.numberOfPages = 7
        pageControl.currentPage = 0
        //实现缩放效果呢
        //scrollview.minimumZoomScale = 0.2
        //scrollview.maximumZoomScale = 5
        scrollview.delegate = self
    }


    //支持点击页面跳转
    
    @IBAction func pageControllClicked(_ sender: UIPageControl) {
        let currentPage = sender.currentPage
        let rect = CGRect(x: CGFloat(currentPage) * scrollview.bounds.width, y: 0, width: scrollview.bounds.width, height: scrollview.bounds.height)
        scrollview.scrollRectToVisible(rect, animated: true)
    }
    
    //支持拖页面
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let currentPage = scrollview.contentOffset.x/scrollview.bounds.width
        pageControl.currentPage = Int(currentPage)
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

