//
//  ViewController.swift
//  exp13_1
//
//  Created by 505007 on 2018/12/15.
//  Copyright © 2018年 kicker. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lbltime: UILabel!
    @IBOutlet weak var result: UILabel!
    
    @IBOutlet weak var counter: UILabel!
    var count = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (timer) in
            self.count += 1
            self.counter.text = "计时器：\(self.count)"
            print("timer thread: \(Thread.current)")
        }
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.

    }
    

    @IBAction func getCalRsult(_ sender: UIButton) {
        var sum = 0
        DispatchQueue.global().async {
            print("sum thread: \(Thread.current)")
            
            for i in 1...9999999{
                sum += i
            }
            //ui 操作只能放倒主线程中
            DispatchQueue.main.async {
                self.result.text = "\(sum)"
            }
        }
        
    }
    
    @IBAction func getDateTime(_ sender: Any) {
        let now = Date()
        print("\(now)")
        let  dateformatter_mine = "yyyy-MM-dd  HH:mm:ss zzz EEEE GGG "
        let formatter = DateFormatter()
        formatter.dateFormat = dateformatter_mine
        formatter.timeZone = NSTimeZone.local
        let reuslt_time_str = formatter.string(from: now)
        lbltime.text =  reuslt_time_str
    }
    
}

