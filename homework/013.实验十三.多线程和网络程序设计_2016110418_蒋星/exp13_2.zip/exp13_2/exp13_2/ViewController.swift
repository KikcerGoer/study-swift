//
//  ViewController.swift
//  exp13_2
//
//  Created by 505007 on 2018/12/15.
//  Copyright © 2018年 kicker. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    @IBOutlet weak var tfurl: UITextField!
    
    @IBOutlet weak var uiweb: WKWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let url = URL(string:"https://www.hao123.com/"){
            uiweb.load(URLRequest(url:url))
        }
       
        
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func back(_ sender: UIButton) {
        uiweb.goBack()
    }
    
    
    @IBAction func forward(_ sender: UIButton) {
        uiweb.goForward()
    }
    
    @IBAction func reload(_ sender: UIButton) {
        uiweb.reload()
    }
    
    
    @IBAction func gotoload(_ sender: Any) {
        if let url = URL(string:tfurl.text!){
            uiweb.load(URLRequest(url:url))
        }
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

