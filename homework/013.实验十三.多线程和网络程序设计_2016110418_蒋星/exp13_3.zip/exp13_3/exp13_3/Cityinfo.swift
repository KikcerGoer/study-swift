//
//  Cityinfo.swift
//  exp13_3
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 Jxkicker. All rights reserved.
//

import Foundation

class Cityinfo {
    var shidu:String = ""
    var pm25:String = ""
    var quality:String = ""
    var  wendu:String = ""
    var ganmaoadvice:String = ""
    var city:String = ""
    var updateTime:String = ""
    var time:String = ""
}
