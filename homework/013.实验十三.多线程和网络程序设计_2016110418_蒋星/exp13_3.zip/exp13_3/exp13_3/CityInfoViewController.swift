//
//  CityInfoViewController.swift
//  exp13_3
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 Jxkicker. All rights reserved.
//

import UIKit
import Alamofire

class CityInfoViewController: UIViewController {

    
    //北京: 101010100
    //成都: 101270101
    //重庆: 101040100
    //上海: 101020100
    //天津: 101030100
    //黑龙江:101050101
    
    let citycode:[String:String] = ["北京":"101010100","成都":"101270101","重庆":"101040100","上海":"101020100","天津":"101030100","黑龙江":"101050101"]
    
    var cityinfo:Cityinfo?
    var sendcityname:String?
    
    @IBOutlet weak var cityname: UILabel!
    @IBOutlet weak var pm25status: UILabel!
    @IBOutlet weak var shidustatus: UILabel!
    @IBOutlet weak var wendu: UILabel!
    @IBOutlet weak var updatetime: UILabel!
    @IBOutlet weak var nowtime: UILabel!
    @IBOutlet weak var quality: UILabel!
    @IBOutlet weak var advice: UILabel!
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        let url_ = "http://t.weather.sojson.com/api/weather/city/\(citycode[sendcityname!] ?? "101270101")"
        let url = URL(string:url_)!
        AF.request(url).responseJSON {(response) in
            
            self.cityinfo = Cityinfo()
            
            // print(response.data!) //没有序列化的json 数据
            // print(response.result.value!) // 序列化的json
            let json_ = response.result.value as! Dictionary<String,AnyObject>
            let cityInfo = json_["cityInfo"]  as! Dictionary<String,AnyObject>
            
            
            let todayinfo = json_["data"] as! Dictionary<String,AnyObject>
            // 2.得到湿度
            self.cityinfo?.shidu = todayinfo["shidu"] as! String
            // 3.得到pm25
            self.cityinfo?.pm25 = "\(todayinfo["pm25"] as! Int)"
            // 4.得到建议
            self.cityinfo?.ganmaoadvice = todayinfo["ganmao"] as! String
            // 5.得到时间
            self.cityinfo?.time = json_["time"] as! String
            // 6.得到空气质量
            self.cityinfo?.quality = todayinfo["quality"] as! String
            // 7.得到更新时间
            self.cityinfo?.updateTime = cityInfo["updateTime"] as! String
            // 8.获取温度
            self.cityinfo?.wendu = todayinfo["wendu"] as! String
            
            self.update()
        }
        

        // Do any additional setup after loading the view.
    }
    
    func update(){
        cityname.text = "城市:" + sendcityname!
        pm25status.text = "PM2.5:" + (cityinfo?.pm25)!
        shidustatus.text = "湿度:" + (cityinfo?.shidu)!
        wendu.text = "温度:" + (cityinfo?.wendu)!
        updatetime.text = "更新时间:" + (cityinfo?.updateTime)!
        nowtime.text = "当前时间:" + (cityinfo?.time)!
        quality.text = "空气质量:" + (cityinfo?.quality)!
        advice.text = "气象建议:" + (cityinfo?.ganmaoadvice)!
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
