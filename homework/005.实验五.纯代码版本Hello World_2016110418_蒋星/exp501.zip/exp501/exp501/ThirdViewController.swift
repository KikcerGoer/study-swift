//
//  ThirdViewController.swift
//  exp501
//
//  Created by student on 2018/11/24.
//  Copyright © 2018年 jxkicker. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    
    @IBOutlet var lbl: UILabel!
    
    @IBAction func makechange(_ sender: UISwitch) {
        if(sender.isOn == true){
            lbl.text = "label : 开关是开的"
            view.backgroundColor = UIColor.white
        }else{
            lbl.text = "label : 开关是关的"
            view.backgroundColor = UIColor.black
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lbl = UILabel(frame: CGRect(x:20,y:200,width:view.bounds.width - 40,height: 40))
        lbl.backgroundColor = UIColor.white
        lbl.textColor = UIColor.black
        lbl.text = "现在灯管明亮"
        lbl.textAlignment = .center
        
        self.title = "Third"
        self.view.backgroundColor = UIColor.white
        
        let switch_my:UISwitch = UISwitch(frame:CGRect(x:view.bounds.width - 110,y:100,width:100,height:40))
        
        view.addSubview(lbl)
        view.addSubview(switch_my)
        switch_my.isOn = true
        switch_my.addTarget(self, action: #selector(makechange), for: .valueChanged)
        
        
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
