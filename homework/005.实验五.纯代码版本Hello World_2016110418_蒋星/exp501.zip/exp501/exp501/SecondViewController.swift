//
//  SecondViewController.swift
//  exp501
//
//  Created by student on 2018/11/24.
//  Copyright © 2018年 jxkicker. All rights reserved.
//

import Foundation;
import UIKit;

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        let imageView = UIImageView(frame: CGRect(x: 10, y: 200, width: self.view.bounds.width - 20, height: 500))
        imageView.image =  UIImage(named: "kicker")
        view.addSubview(imageView)
        let button = UIButton(frame: CGRect(x: 100, y: 100, width: 200, height: 35))
        button.setTitle("点我 看到不一样的世界", for: .normal)
        button.backgroundColor = UIColor.orange
        
        button.setTitleColor(UIColor.white, for: .normal)
        view.addSubview(button)
        
        button.addTarget(self, action: #selector(btnClicked), for: .touchUpInside)
        
        self.title = "Second"

    }
    @IBAction func btnClicked() {
        //        presentingViewController?.dismiss(animated: true, completion: nil)
        navigationController?.pushViewController(ThirdViewController(), animated: true)
    }
    
    
    

}
