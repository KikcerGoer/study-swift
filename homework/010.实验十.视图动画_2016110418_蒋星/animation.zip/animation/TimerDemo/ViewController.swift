//
//  ViewController.swift
//  TimerDemo
//
//  Created by 505007 on 2018/11/27.
//  Copyright © 2018年 505007. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myview: UIView!
    
    var  timer:Timer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: {[weak weakSelf = self](mytimer) in
            if self.myview.center.x + self.myview.bounds.width * 1.5 + 15 < self.view.bounds.width {
               weakSelf?.self.myview.center.x += 15
            }
        })
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func StopMoveClicke(_ sender: UIButton) {
        timer?.invalidate()
        //在几秒内 透明度变成0
        
        UIView.animate(withDuration: 4, delay: 0, options: [.autoreverse,.curveLinear], animations: {
            self.myview.alpha = 0
            self.myview.center.x += self.myview.bounds.width
            self.myview.backgroundColor = UIColor.red
            //旋转
            self.myview.transform = CGAffineTransform(rotationAngle:CGFloat(Double.pi))
            //伸缩
            //.scaledBy(x: 0.5, y: 0.5)
            self.myview.transform = CGAffineTransform.identity
            
            self.myview.transform = CGAffineTransform(rotationAngle:CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
            self.myview.transform = CGAffineTransform(rotationAngle:CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
            self.myview.transform = CGAffineTransform(rotationAngle:CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
            self.myview.transform = CGAffineTransform(rotationAngle:CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
            self.myview.transform = CGAffineTransform(rotationAngle:CGFloat(Double.pi))
            self.myview.transform = CGAffineTransform.identity
        }, completion: { (finish) in
            if finish {
                self.myview.removeFromSuperview()
            }
        })
        
        
        /* //使用简单动画的结果
        UIView.animate(withDuration: 2){
            self.myview.alpha = 0
        }
        */
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
        
    }


}

