//
//  ViewController.swift
//  dynamicAnimate
//
//  Created by 505007 on 2018/11/27.
//  Copyright © 2018年 505007. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    lazy var animator = UIDynamicAnimator(referenceView:self.backView)
    @IBOutlet weak var backView: UIView!
    
    //物理引擎
    let gravity = UIGravityBehavior() //重力效果
    let collision = UICollisionBehavior() // 碰撞效果
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //物理效果添加到视图中
        animator.addBehavior(gravity)
        animator.addBehavior(collision)
        //防止跌落出边框 越界
        collision.translatesReferenceBoundsIntoBoundary = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func add(_ sender: UIButton) {
        let width = Int(self.backView.bounds.width / 10)
        let randx = Int(arc4random() % 10) * width
        
        let label = UILabel(frame:CGRect(x:randx,y:20,width:width,height:width))
        
        label.backgroundColor = UIColor.purple
        label.text = "王"
        label.textColor = UIColor.white
        label.textAlignment = .center
        self.backView.addSubview(label)
        //给视图施加重力影响
        gravity.addItem(label)
        collision.addItem(label)
    }
    
    
    
    @IBAction func up(_ sender: UIButton) {
        gravity.gravityDirection = CGVector(dx:0,dy:-1)
    }
    
    @IBAction func down(_ sender: UIButton) {
        gravity.gravityDirection = CGVector(dx:0,dy:1)
    }
    
    @IBAction func left(_ sender: UIButton) {
        gravity.gravityDirection = CGVector(dx:-1,dy:0)
    }
    
    
    @IBAction func right(_ sender: UIButton) {
        gravity.gravityDirection = CGVector(dx:1,dy:0)
    }
    
    @IBAction func deleteAll(_ sender: Any) {
        for item in backView.subviews{
            if item  is UILabel {
                item.removeFromSuperview()
                gravity.removeItem(item)
                collision.removeItem(item)
            }
        }
    }
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}

