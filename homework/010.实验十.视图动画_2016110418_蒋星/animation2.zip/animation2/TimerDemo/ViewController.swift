//
//  ViewController.swift
//  TimerDemo
//
//  Created by 505007 on 2018/11/27.
//  Copyright © 2018年 505007. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var myview: UIView!
    
    @IBOutlet weak var myview2: UIView!
    
    @IBOutlet weak var myview3: UIView!
    
    @IBOutlet weak var myview4: UIView!
    
    @IBOutlet weak var myview5: UIView!
    
    @IBOutlet weak var myview6: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func StopMoveClicke(_ sender: UIButton) {
        //翻书动画
        UIView.transition(with: myview, duration: 2, options: .transitionCurlUp, animations: { self.myview.backgroundColor = UIColor.green }, completion: nil)

        //从上向下翻转
        UIView.transition(with: myview2, duration: 2, options: .transitionFlipFromTop, animations: { self.myview2.backgroundColor = UIColor.green }, completion: nil)
        //从左向右边翻转
        UIView.transition(with: myview3, duration: 2, options: .transitionFlipFromLeft, animations: { self.myview3.backgroundColor = UIColor.green }, completion: nil)

        /*
        let imageView = UIImageView(frame:CGRect(x:50,y:50,width:100,height:100))
        imageView.image = UIImage(named:"xjp")
        UIView.transition(from: myview4, to: imageView, duration: 2, options: .transitionFlipFromLeft, completion: nil)
        */
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

